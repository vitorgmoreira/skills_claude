# Templates markdown serão criados aqui durante a conversão
